const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireAdmin, requireLecturer } = require('../middleware/auth');

// ─── COURSE CRUD ────────────────────────────────────────────────────────────

// POST /api/courses  –  Create a course (Admin only)
router.post('/', authenticate, requireAdmin, async (req, res) => {
  const { course_id, course_name, description } = req.body;

  if (!course_id || !course_name) {
    return res.status(400).json({ error: 'course_id and course_name are required' });
  }

  try {
    await pool.query(
      'INSERT INTO Course (course_id, course_name, description) VALUES (?, ?, ?)',
      [course_id, course_name, description || null]
    );
    res.status(201).json({ message: 'Course created successfully', course_id });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Course ID already exists' });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to create course' });
  }
});

// GET /api/courses  –  All courses
router.get('/', authenticate, async (req, res) => {
  try {
    const [courses] = await pool.query('SELECT * FROM Course ORDER BY course_id');
    res.json(courses);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve courses' });
  }
});

// GET /api/courses/student/:userId  –  Courses a student is enrolled in
// NOTE: specific literal paths must come BEFORE /:courseId patterns
router.get('/student/:userId', authenticate, async (req, res) => {
  const { userId } = req.params;
  try {
    const [courses] = await pool.query(
      `SELECT c.*, at.enrollment_date
       FROM Course c
       JOIN Assigned_To at ON c.course_id = at.course_id
       WHERE at.user_id = ?
       ORDER BY c.course_id`,
      [userId]
    );
    res.json(courses);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve courses' });
  }
});

// GET /api/courses/lecturer/:userId  –  Courses taught by a lecturer
router.get('/lecturer/:userId', authenticate, async (req, res) => {
  const { userId } = req.params;
  try {
    const [courses] = await pool.query(
      `SELECT c.*
       FROM Course c
       JOIN Maintains m ON c.course_id = m.course_id
       WHERE m.user_id = ?
       ORDER BY c.course_id`,
      [userId]
    );
    res.json(courses);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve courses' });
  }
});

// GET /api/courses/:courseId  –  Single course
router.get('/:courseId', authenticate, async (req, res) => {
  const { courseId } = req.params;
  try {
    const [rows] = await pool.query(
      'SELECT * FROM Course WHERE course_id = ?',
      [courseId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Course not found' });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve course' });
  }
});

// ─── ENROLLMENT ──────────────────────────────────────────────────────────────

// POST /api/courses/:courseId/enroll  –  Enroll a student
// Students enroll themselves; Admins can specify a user_id in the body
router.post('/:courseId/enroll', authenticate, async (req, res) => {
  const { courseId } = req.params;

  let targetUserId;
  if (req.user.user_type === 'Student') {
    targetUserId = req.user.user_id;
  } else if (req.user.user_type === 'Admin') {
    targetUserId = req.body.user_id;
  } else {
    return res.status(403).json({ error: 'Only students or admins can enroll students' });
  }

  if (!targetUserId) {
    return res.status(400).json({ error: 'user_id is required' });
  }

  try {
    // Verify student record exists
    const [student] = await pool.query(
      'SELECT user_id FROM Student WHERE user_id = ?',
      [targetUserId]
    );
    if (student.length === 0) {
      return res.status(404).json({ error: 'Student not found' });
    }

    // Verify course exists
    const [course] = await pool.query(
      'SELECT course_id FROM Course WHERE course_id = ?',
      [courseId]
    );
    if (course.length === 0) {
      return res.status(404).json({ error: 'Course not found' });
    }

    // Enforce max 6 courses per student
    const [countRows] = await pool.query(
      'SELECT COUNT(*) AS cnt FROM Assigned_To WHERE user_id = ?',
      [targetUserId]
    );
    if (countRows[0].cnt >= 6) {
      return res.status(400).json({ error: 'Student is already enrolled in the maximum of 6 courses' });
    }

    const enrollmentDate = new Date().toISOString().split('T')[0];
    await pool.query(
      'INSERT INTO Assigned_To (user_id, course_id, enrollment_date) VALUES (?, ?, ?)',
      [targetUserId, courseId, enrollmentDate]
    );

    res.status(201).json({ message: 'Student enrolled successfully' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Student is already enrolled in this course' });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to enroll student' });
  }
});

// POST /api/courses/:courseId/assign-lecturer  –  Assign a lecturer (Admin only)
router.post('/:courseId/assign-lecturer', authenticate, requireAdmin, async (req, res) => {
  const { courseId } = req.params;
  const { user_id }  = req.body;

  if (!user_id) {
    return res.status(400).json({ error: 'user_id is required' });
  }

  try {
    // Verify lecturer record exists
    const [lecturer] = await pool.query(
      'SELECT user_id FROM Lecturer WHERE user_id = ?',
      [user_id]
    );
    if (lecturer.length === 0) {
      return res.status(404).json({ error: 'Lecturer not found' });
    }

    // Verify course exists
    const [course] = await pool.query(
      'SELECT course_id FROM Course WHERE course_id = ?',
      [courseId]
    );
    if (course.length === 0) {
      return res.status(404).json({ error: 'Course not found' });
    }

    // Enforce only one lecturer per course
    const [existing] = await pool.query(
      'SELECT user_id FROM Maintains WHERE course_id = ?',
      [courseId]
    );
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Course already has a lecturer assigned' });
    }

    // Enforce max 5 courses per lecturer
    const [countRows] = await pool.query(
      'SELECT COUNT(*) AS cnt FROM Maintains WHERE user_id = ?',
      [user_id]
    );
    if (countRows[0].cnt >= 5) {
      return res.status(400).json({ error: 'Lecturer already teaches the maximum of 5 courses' });
    }

    await pool.query(
      'INSERT INTO Maintains (user_id, course_id) VALUES (?, ?)',
      [user_id, courseId]
    );

    res.status(201).json({ message: 'Lecturer assigned to course successfully' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Lecturer is already assigned to this course' });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to assign lecturer' });
  }
});

// ─── MEMBERS ─────────────────────────────────────────────────────────────────

// GET /api/courses/:courseId/members  –  All members (lecturer + students)
router.get('/:courseId/members', authenticate, async (req, res) => {
  const { courseId } = req.params;
  try {
    const [lecturers] = await pool.query(
      `SELECT u.user_id, u.name, u.email, 'Lecturer' AS role, l.department
       FROM \`User\` u
       JOIN Lecturer l ON u.user_id = l.user_id
       JOIN Maintains m ON l.user_id = m.user_id
       WHERE m.course_id = ?`,
      [courseId]
    );

    const [students] = await pool.query(
      `SELECT u.user_id, u.name, u.email, 'Student' AS role, at.enrollment_date
       FROM \`User\` u
       JOIN Assigned_To at ON u.user_id = at.user_id
       WHERE at.course_id = ?
       ORDER BY u.name`,
      [courseId]
    );

    res.json({ lecturers, students });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve members' });
  }
});

// ─── CALENDAR EVENTS ─────────────────────────────────────────────────────────

// GET /api/courses/:courseId/events  –  All calendar events for a course
router.get('/:courseId/events', authenticate, async (req, res) => {
  const { courseId } = req.params;
  try {
    const [events] = await pool.query(
      `SELECT * FROM Calendar_Event
       WHERE course_id = ?
       ORDER BY event_date`,
      [courseId]
    );
    res.json(events);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve calendar events' });
  }
});

// POST /api/courses/:courseId/events  –  Create a calendar event (Lecturer/Admin)
router.post('/:courseId/events', authenticate, requireLecturer, async (req, res) => {
  const { courseId } = req.params;
  const { title, description, event_date, event_type } = req.body;

  if (!title || !event_date) {
    return res.status(400).json({ error: 'title and event_date are required' });
  }

  try {
    const [result] = await pool.query(
      `INSERT INTO Calendar_Event (course_id, title, description, event_date, event_type)
       VALUES (?, ?, ?, ?, ?)`,
      [courseId, title, description || null, event_date, event_type || null]
    );
    res.status(201).json({ message: 'Calendar event created', event_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create calendar event' });
  }
});

module.exports = router;
