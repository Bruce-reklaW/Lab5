const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireLecturer } = require('../middleware/auth');

// GET /api/content/course/:courseId  –  All sections with their items for a course
router.get('/course/:courseId', authenticate, async (req, res) => {
  const { courseId } = req.params;
  try {
    const [sections] = await pool.query(
      `SELECT * FROM Section
       WHERE course_id = ?
       ORDER BY COALESCE(sec_order, section_num)`,
      [courseId]
    );

    // Attach items to each section
    for (const section of sections) {
      const [items] = await pool.query(
        `SELECT * FROM Section_Item
         WHERE course_id = ? AND section_num = ?
         ORDER BY item_id`,
        [courseId, section.section_num]
      );
      section.items = items;
    }

    res.json(sections);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve course content' });
  }
});

// POST /api/content/course/:courseId/sections  –  Add a section (Lecturer/Admin)
router.post('/course/:courseId/sections', authenticate, requireLecturer, async (req, res) => {
  const { courseId }        = req.params;
  const { title, sec_order } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'title is required' });
  }

  try {
    // Verify course exists
    const [course] = await pool.query(
      'SELECT course_id FROM Course WHERE course_id = ?',
      [courseId]
    );
    if (course.length === 0) {
      return res.status(404).json({ error: 'Course not found' });
    }

    // Auto-generate section_num (not AUTO_INCREMENT in schema)
    const [maxRow] = await pool.query(
      'SELECT COALESCE(MAX(section_num), 0) + 1 AS next_num FROM Section WHERE course_id = ?',
      [courseId]
    );
    const section_num = maxRow[0].next_num;

    await pool.query(
      'INSERT INTO Section (course_id, section_num, title, sec_order) VALUES (?, ?, ?, ?)',
      [courseId, section_num, title, sec_order ?? section_num]
    );

    res.status(201).json({
      message:     'Section created successfully',
      course_id:   courseId,
      section_num
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create section' });
  }
});

// POST /api/content/course/:courseId/sections/:sectionNum/items  –  Add item to a section (Lecturer/Admin)
router.post('/course/:courseId/sections/:sectionNum/items', authenticate, requireLecturer, async (req, res) => {
  const { courseId, sectionNum } = req.params;
  const { title, type, content } = req.body;

  if (!title || !type) {
    return res.status(400).json({ error: 'title and type are required' });
  }

  try {
    // Verify section exists
    const [section] = await pool.query(
      'SELECT section_num FROM Section WHERE course_id = ? AND section_num = ?',
      [courseId, sectionNum]
    );
    if (section.length === 0) {
      return res.status(404).json({ error: 'Section not found' });
    }

    const [result] = await pool.query(
      'INSERT INTO Section_Item (course_id, section_num, title, type, content) VALUES (?, ?, ?, ?, ?)',
      [courseId, sectionNum, title, type, content || null]
    );

    res.status(201).json({ message: 'Item added to section', item_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to add item' });
  }
});

module.exports = router;
