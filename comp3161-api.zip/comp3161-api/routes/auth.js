const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const pool    = require('../db');

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { name, email, password, user_type, department, date_enrolled } = req.body;

  if (!name || !email || !password || !user_type) {
    return res.status(400).json({ error: 'name, email, password, and user_type are required' });
  }

  const validTypes = ['Admin', 'Lecturer', 'Student'];
  if (!validTypes.includes(user_type)) {
    return res.status(400).json({ error: 'user_type must be Admin, Lecturer, or Student' });
  }

  if (user_type === 'Lecturer' && !department) {
    return res.status(400).json({ error: 'department is required for Lecturer' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Check for duplicate email
    const [existing] = await conn.query(
      'SELECT user_id FROM `User` WHERE email = ?',
      [email]
    );
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(409).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const [result] = await conn.query(
      'INSERT INTO `User` (name, email, password, user_type) VALUES (?, ?, ?, ?)',
      [name, email, hashedPassword, user_type]
    );
    const userId = result.insertId;

    if (user_type === 'Admin') {
      await conn.query('INSERT INTO Admin (user_id) VALUES (?)', [userId]);
    } else if (user_type === 'Student') {
      const enrollDate = date_enrolled || new Date().toISOString().split('T')[0];
      await conn.query(
        'INSERT INTO Student (user_id, date_enrolled) VALUES (?, ?)',
        [userId, enrollDate]
      );
    } else if (user_type === 'Lecturer') {
      await conn.query(
        'INSERT INTO Lecturer (user_id, department) VALUES (?, ?)',
        [userId, department]
      );
    }

    await conn.commit();
    res.status(201).json({ message: 'User registered successfully', user_id: userId });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  } finally {
    conn.release();
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required' });
  }

  try {
    const [rows] = await pool.query(
      'SELECT user_id, name, email, password, user_type FROM `User` WHERE email = ?',
      [email]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = rows[0];
    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { user_id: user.user_id, email: user.email, user_type: user.user_type },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        user_id:   user.user_id,
        name:      user.name,
        email:     user.email,
        user_type: user.user_type
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed' });
  }
});

module.exports = router;
