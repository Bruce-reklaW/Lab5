const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireLecturer } = require('../middleware/auth');

// ─── ASSIGNMENTS ──────────────────────────────────────────────────────────────

// POST /api/assignments/course/:courseId  –  Create an assignment (Lecturer/Admin)
router.post('/course/:courseId', authenticate, requireLecturer, async (req, res) => {
  const { courseId } = req.params;
  const { title, description, due_date, max_marks } = req.body;

  if (!title || !due_date || max_marks == null) {
    return res.status(400).json({ error: 'title, due_date, and max_marks are required' });
  }
  if (max_marks < 0) {
    return res.status(400).json({ error: 'max_marks must be a non-negative number' });
  }

  try {
    const [result] = await pool.query(
      `INSERT INTO Assignment (course_id, title, description, due_date, max_marks)
       VALUES (?, ?, ?, ?, ?)`,
      [courseId, title, description || null, due_date, max_marks]
    );
    res.status(201).json({ message: 'Assignment created', assignment_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create assignment' });
  }
});

// GET /api/assignments/course/:courseId  –  All assignments for a course
router.get('/course/:courseId', authenticate, async (req, res) => {
  const { courseId } = req.params;
  try {
    const [assignments] = await pool.query(
      'SELECT * FROM Assignment WHERE course_id = ? ORDER BY due_date',
      [courseId]
    );
    res.json(assignments);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve assignments' });
  }
});

// ─── SUBMISSIONS ──────────────────────────────────────────────────────────────

// POST /api/assignments/:assignmentId/submit  –  Student submits an assignment
router.post('/:assignmentId/submit', authenticate, async (req, res) => {
  const { assignmentId } = req.params;
  const user_id          = req.user.user_id;

  if (req.user.user_type !== 'Student') {
    return res.status(403).json({ error: 'Only students can submit assignments' });
  }

  try {
    // Verify assignment exists
    const [assignment] = await pool.query(
      'SELECT assignment_id, course_id FROM Assignment WHERE assignment_id = ?',
      [assignmentId]
    );
    if (assignment.length === 0) {
      return res.status(404).json({ error: 'Assignment not found' });
    }

    const { course_id } = assignment[0];

    // Verify student is enrolled in the course
    const [enrollment] = await pool.query(
      'SELECT user_id FROM Assigned_To WHERE user_id = ? AND course_id = ?',
      [user_id, course_id]
    );
    if (enrollment.length === 0) {
      return res.status(403).json({ error: 'You are not enrolled in this course' });
    }

    // Prevent duplicate submission
    const [existing] = await pool.query(
      'SELECT submission_id FROM Submission WHERE user_id = ? AND assignment_id = ?',
      [user_id, assignmentId]
    );
    if (existing.length > 0) {
      return res.status(409).json({ error: 'Assignment already submitted' });
    }

    const [result] = await pool.query(
      'INSERT INTO Submission (user_id, assignment_id) VALUES (?, ?)',
      [user_id, assignmentId]
    );
    res.status(201).json({ message: 'Assignment submitted successfully', submission_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to submit assignment' });
  }
});

// ─── GRADING ─────────────────────────────────────────────────────────────────

// PUT /api/assignments/submissions/:submissionId/grade  –  Lecturer grades a submission
router.put('/submissions/:submissionId/grade', authenticate, requireLecturer, async (req, res) => {
  const { submissionId } = req.params;
  const { grade }        = req.body;

  if (grade == null) {
    return res.status(400).json({ error: 'grade is required' });
  }

  try {
    // Fetch submission to validate bounds
    const [rows] = await pool.query(
      `SELECT s.submission_id, a.max_marks
       FROM Submission s
       JOIN Assignment a ON s.assignment_id = a.assignment_id
       WHERE s.submission_id = ?`,
      [submissionId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Submission not found' });
    }

    const { max_marks } = rows[0];
    if (grade < 0 || grade > max_marks) {
      return res.status(400).json({ error: `Grade must be between 0 and ${max_marks}` });
    }

    await pool.query(
      'UPDATE Submission SET grade = ? WHERE submission_id = ?',
      [grade, submissionId]
    );
    res.json({ message: 'Grade submitted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to submit grade' });
  }
});

// ─── STUDENT AVERAGE ─────────────────────────────────────────────────────────

// GET /api/assignments/students/:userId/average  –  Overall graded average for a student
// Average is computed as the mean of (grade / max_marks * 100) per graded submission
router.get('/students/:userId/average', authenticate, async (req, res) => {
  const { userId } = req.params;
  try {
    const [rows] = await pool.query(
      `SELECT
         u.user_id,
         u.name,
         u.email,
         ROUND(AVG(sub.grade / a.max_marks * 100), 2) AS overall_average,
         COUNT(sub.submission_id)                       AS total_graded
       FROM \`User\` u
       JOIN Submission sub ON u.user_id = sub.user_id
       JOIN Assignment a   ON sub.assignment_id = a.assignment_id
       WHERE u.user_id = ? AND sub.grade IS NOT NULL
       GROUP BY u.user_id, u.name, u.email`,
      [userId]
    );

    if (rows.length === 0) {
      return res.json({ user_id: parseInt(userId), overall_average: null, total_graded: 0 });
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve average' });
  }
});

module.exports = router;
