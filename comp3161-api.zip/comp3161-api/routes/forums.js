const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireLecturer } = require('../middleware/auth');

// GET /api/forums/course/:courseId  –  All forums for a course
router.get('/course/:courseId', authenticate, async (req, res) => {
  const { courseId } = req.params;
  try {
    const [forums] = await pool.query(
      'SELECT * FROM Discussion_Forum WHERE course_id = ? ORDER BY forum_id',
      [courseId]
    );
    res.json(forums);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve forums' });
  }
});

// POST /api/forums/course/:courseId  –  Create a forum (Lecturer/Admin)
router.post('/course/:courseId', authenticate, requireLecturer, async (req, res) => {
  const { courseId } = req.params;
  const { title, description } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'title is required' });
  }

  try {
    // Verify course exists
    const [course] = await pool.query(
      'SELECT course_id FROM Course WHERE course_id = ?',
      [courseId]
    );
    if (course.length === 0) {
      return res.status(404).json({ error: 'Course not found' });
    }

    const [result] = await pool.query(
      'INSERT INTO Discussion_Forum (course_id, title, description) VALUES (?, ?, ?)',
      [courseId, title, description || null]
    );
    res.status(201).json({ message: 'Forum created successfully', forum_id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create forum' });
  }
});

module.exports = router;
