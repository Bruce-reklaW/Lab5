const express = require('express');
const router  = express.Router();
const pool    = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

// GET /api/reports/courses-50-plus-students
router.get('/courses-50-plus-students', authenticate, requireAdmin, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM CoursesWith50PlusStudents');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve report' });
  }
});

// GET /api/reports/students-5-plus-courses
router.get('/students-5-plus-courses', authenticate, requireAdmin, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM StudentsWith5PlusCourses');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve report' });
  }
});

// GET /api/reports/lecturers-3-plus-courses
router.get('/lecturers-3-plus-courses', authenticate, requireAdmin, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM LecturersWith3PlusCourses');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve report' });
  }
});

// GET /api/reports/top-10-enrolled
router.get('/top-10-enrolled', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Top10EnrolledCourses');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve report' });
  }
});

// GET /api/reports/top-10-students
router.get('/top-10-students', authenticate, async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM Top10StudentAverages');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to retrieve report' });
  }
});

module.exports = router;
