require('dotenv').config();
const express = require('express');

const app = express();
app.use(express.json());

// Routes
app.use('/api/auth',        require('./routes/auth'));
app.use('/api/courses',     require('./routes/courses'));
app.use('/api/forums',      require('./routes/forums'));
app.use('/api/threads',     require('./routes/threads'));
app.use('/api/content',     require('./routes/content'));
app.use('/api/assignments', require('./routes/assignments'));
app.use('/api/students',    require('./routes/students'));
app.use('/api/reports',     require('./routes/reports'));

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
