const jwt = require('jsonwebtoken');

function authenticate(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Expect: Bearer <token>

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = decoded;
    next();
  });
}

function requireAdmin(req, res, next) {
  if (req.user.user_type !== 'Admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// Lecturers AND Admins can perform lecturer actions
function requireLecturer(req, res, next) {
  if (req.user.user_type !== 'Lecturer' && req.user.user_type !== 'Admin') {
    return res.status(403).json({ error: 'Lecturer or Admin access required' });
  }
  next();
}

module.exports = { authenticate, requireAdmin, requireLecturer };
