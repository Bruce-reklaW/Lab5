# INFO3180 Project 1 — Property Listings Flask App

A Flask web application that allows users to add, list, and view properties for rent or sale. Data is stored in a PostgreSQL database.

---

## Project Structure

```
Assignments/
├── app/
│   ├── __init__.py          # App factory (SQLAlchemy, Migrate, CSRF)
│   ├── models.py            # Property database model
│   ├── forms.py             # Flask-WTF form
│   ├── views.py             # Route handlers
│   ├── static/
│   │   ├── css/style.css
│   │   └── uploads/         # Uploaded property photos
│   └── templates/
│       ├── base.html
│       ├── header.html
│       └── properties/
│           ├── create.html
│           ├── list.html
│           └── detail.html
├── migrations/              # Flask-Migrate migration files
├── config.py
├── run.py
├── requirements.txt
└── .env.example
```

---

## Setup

### 1. Create & activate virtual environment
```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure environment
```bash
copy .env.example .env
```
Edit `.env` and set your `SECRET_KEY` and `DATABASE_URL`:
```
SECRET_KEY=your-secret-key-here
DATABASE_URL=postgresql://username:password@localhost/info3180_project1
```

### 4. Create the PostgreSQL database
```sql
CREATE DATABASE info3180_project1;
```

### 5. Run database migrations
```bash
flask db init
flask db migrate -m "Initial migration"
flask db upgrade
```

### 6. Run the application
```bash
flask run
```
Visit `http://127.0.0.1:5000`

---

## Routes

| Route | Method | Description |
|---|---|---|
| `/properties/create` | GET / POST | Add a new property |
| `/properties` | GET | List all properties |
| `/properties/<id>` | GET | View individual property |

---

## Grading Checklist

- [x] 3 routes defined with view functions
- [x] Form with all required fields (title, description, bedrooms, bathrooms, location, price, type, photo)
- [x] Form validates and saves to database with flash message
- [x] File upload stored in `static/uploads/`, filename saved in DB
- [x] Individual property view at `/properties/<propertyid>`
- [x] Properties list at `/properties`
- [x] `Property` model in `models.py`
- [x] Migration file generated
- [x] Nav links for "Properties" and "New Property" in `header.html`
- [x] Page layouts match provided screenshots
