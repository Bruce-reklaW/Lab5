﻿from flask import Flask
from flask_wtf.csrf import CSRFProtect
from flask_migrate import Migrate
from .config import Config
from .models import db

app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db.init_app(app)
migrate = Migrate(app, db)
csrf = CSRFProtect(app)

from app import views
