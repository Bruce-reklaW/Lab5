﻿# INFO3180 Lab 5 - VueJS and Flask API Implementation

## Project Structure

This project is a full-stack application with:

### Backend (Flask)
- **app/forms.py** - MovieForm with title, description, and poster fields
- **app/models.py** - Movie model for database
- **app/views.py** - API endpoints for movies
- **app/config.py** - Configuration with SQLAlchemy setup
- **app/__init__.py** - Flask app initialization with CSRF protection

### Frontend (VueJS 3)
- **src/components/MovieForm.vue** - Form component for adding movies
- **src/components/AppHeader.vue** - Navigation header with links
- **src/views/AddMovieFormView.vue** - Page for adding movies
- **src/views/MoviesView.vue** - Page displaying all movies

## Setup Instructions

### 1. Create PostgreSQL Database

`sql
CREATE DATABASE lab5;
`

### 2. Install Backend Dependencies

`powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
`

### 3. Initialize Database

`powershell
# Create tables
python wsgi.py

# Or use Flask-Migrate if preferred:
# flask db init
# flask db migrate
# flask db upgrade
`

### 4. Start Flask Backend

`powershell
# In a terminal, activate venv and run:
flask --app app --debug run
`

The Flask API will run on http://localhost:8080

### 5. Install Frontend Dependencies

`powershell
# In another terminal (from project root):
npm install
`

### 6. Start VueJS Development Server

`powershell
npm run dev
`

The VueJS frontend will run on http://localhost:5173

## Features Implemented

### Exercise 1: MovieForm Class 
- title (StringField) - Required
- description (TextAreaField) - Required
- poster (FileField) - Required, images only

### Exercise 2: Movie Model 
- id (Integer, Primary Key)
- title (String)
- description (Text)
- poster (String - filename)
- created_at (DateTime)

### Exercise 3: Flask API Routes 
- GET /api/v1/csrf-token - Get CSRF token
- POST /api/v1/movies - Add a movie (validates form, saves file, returns JSON)
- GET /api/v1/movies - Get all movies
- GET /api/v1/posters/<filename> - Serve poster images

### Exercise 4: VueJS Form Component 
- MovieForm.vue with form fields
- CSRF token handling
- FormData for file uploads
- Success and error message display
- Form validation feedback

### Exercise 5: VueJS Movies Display 
- MoviesView.vue displays all movies as cards
- Movie title, description, and poster image
- Responsive grid layout

## API Response Examples

### Add Movie (POST /api/v1/movies)
Success:
`json
{
  "message": "Movie Successfully added",
  "title": "The Matrix",
  "poster": "/api/v1/posters/1640000000.0_poster.jpg",
  "description": "A sci-fi classic"
}
`

Validation Error:
`json
{
  "errors": [
    "Error in the title field - This field is required.",
    "Error in the description field - This field is required."
  ]
}
`

### Get Movies (GET /api/v1/movies)
`json
{
  "movies": [
    {
      "id": 1,
      "title": "The Matrix",
      "description": "A sci-fi classic",
      "poster": "/api/v1/posters/1640000000.0_poster.jpg"
    }
  ]
}
`

## CORS/CSRF Configuration

- CSRF protection is enabled globally in Flask
- VueJS fetches CSRF token from /api/v1/csrf-token
- CSRF token is sent in X-CSRFToken header with POST requests
- Vite proxy (vite.config.js) routes /api/* requests to Flask backend

## File Structure

`
info3180-lab5/
 app/
    __init__.py
    config.py
    forms.py
    models.py
    views.py
 src/
    components/
       AppHeader.vue
       MovieForm.vue
    views/
       AddMovieFormView.vue
       MoviesView.vue
       HomeView.vue
       AboutView.vue
    router/
       index.js
    App.vue
 .env
 vite.config.js
 wsgi.py
 package.json
 requirements.txt
 README.md
`

## Notes

- The .env file contains database credentials and configuration
- Upload folder is automatically created when first poster is uploaded
- Filenames are made unique by prepending timestamp
- All images are served securely using secure_filename()

## Bonus Features

Success/error messages are displayed directly on the form (not just in console):
- Green success alert at top of form when movie is added
- Red error alert listing validation errors
- Alerts can be dismissed

## Troubleshooting

1. **CORS errors**: Make sure vite.config.js proxy is configured and Vite dev server is restarted
2. **Database connection**: Check DATABASE_URL in .env file
3. **File upload errors**: Ensure uploads folder exists and is writable
4. **Port conflicts**: Flask uses 8080, VueJS uses 5173
