﻿# Lab 5 Implementation Summary

##  Exercise 1: MovieForm Class (2 marks)
**File**: app/forms.py
- Created MovieForm class using Flask-WTF
- title field: StringField with DataRequired validator
- description field: TextAreaField with DataRequired validator
- poster field: FileField with DataRequired validator and FileAllowed(['jpg', 'jpeg', 'png', 'gif'])

##  Exercise 2: Movies Database Table (3 marks)
**File**: app/models.py
- Created Movie model with SQLAlchemy
- Columns: id (primary key), title, description, poster, created_at
- Database name: 'lab5'
- Table name: 'movies'
- SQLAlchemy initialized in models.py and registered in __init__.py
- Flask-Migrate setup in __init__.py for database migrations

##  Exercise 3: Flask API Route (5 marks)
**File**: app/views.py
- Route: /api/v1/movies [POST, GET]
- POST: Validates form, saves file to uploads folder, stores in database
- Returns JSON: {message, title, poster, description} on success
- Returns JSON: {errors: []} on validation failure
- GET: Retrieves all movies from database, returns JSON list
- Additional routes:
  - GET /api/v1/csrf-token: Returns CSRF token for frontend
  - GET /api/v1/posters/<filename>: Serves poster images

##  Exercise 4: VueJS Frontend Form (5 marks)
**Files**: 
- src/components/MovieForm.vue
- src/views/AddMovieFormView.vue
- src/router/index.js (route: /movies/create)

Features:
- Form with title, description, and poster file input
- getCsrfToken() method fetches token on mount
- saveMovie() method makes AJAX POST request with FormData
- Sends X-CSRFToken header with CSRF token
- Displays success message on success
- Displays validation errors on failure
- Form resets after successful submission
- Bootstrap styling for alerts and form

##  Exercise 5: VueJS Movies Display Page (5 marks)
**Files**:
- src/views/MoviesView.vue
- src/router/index.js (route: /movies)

Features:
- Fetches movies on component mount
- Displays movies as Bootstrap cards in responsive grid
- Shows movie poster, title, and description
- Empty state message with link to add movie

## Additional Implementation
**Files Updated**:
- src/components/AppHeader.vue: Added navigation links to /movies and /movies/create
- app/__init__.py: Integrated SQLAlchemy, Flask-Migrate, CSRF protection
- app/config.py: PostgreSQL database configuration
- vite.config.js: Added proxy for /api routes to Flask backend
- .env: Environment variables for database and configuration
- wsgi.py: Entry point for running Flask app

## Bonus: Success/Error Messages Display 
- Success messages display in green alert at top of form
- Validation error messages display in red alert listing each error
- Alerts are dismissible
- Form data is cleared after successful submission

## Project Setup
Location: C:\Users\brucew\info3180-lab5

To run the project:
1. Create PostgreSQL database: CREATE DATABASE lab5;
2. Backend: flask --app app --debug run (runs on port 8080)
3. Frontend: npm run dev (runs on port 5173)
4. Access at: http://localhost:5173

All files are committed to git repository.
